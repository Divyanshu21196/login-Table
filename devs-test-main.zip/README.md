
#Description

Project contains 2 pages login and table.
Data for project in files “assets/mocks/” folder

#Task 1:
On user submit click load “login.json” and check if user input matches “login.json” values.
If yes, go the “table” route  Otherwise show error.

#Task2
Make login page default page of application

#Task3
In “table-page” component load “strategies.json” file and populate data according image provided in root of repo “table-page.PNG”


